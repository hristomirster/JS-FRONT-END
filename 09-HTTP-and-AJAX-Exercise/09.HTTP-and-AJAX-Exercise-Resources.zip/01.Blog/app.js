function attachEvents() {
    // TODO:
}

attachEvents();